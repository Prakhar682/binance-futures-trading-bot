import os
from dotenv import load_dotenv
from binance.client import Client

load_dotenv()
api_key = os.getenv("BINANCE_API_KEY")
api_secret = os.getenv("BINANCE_API_SECRET")

print("API_KEY:", api_key)
print("API_SECRET:", api_secret)

client = Client(api_key, api_secret)
client.API_URL = "https://testnet.binancefuture.com"

try:
    server_time = client.get_server_time()
    print("✅ Connected to Binance Futures Testnet")
    print("Server time:", server_time)
except Exception as e:
    print("❌ Error connecting:", e)
