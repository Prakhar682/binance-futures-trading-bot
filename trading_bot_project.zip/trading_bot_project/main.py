import sys
import os
from dotenv import load_dotenv
from basic_bot import BasicBot

def main():
    load_dotenv()
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    if not api_key or not api_secret:
        print("❌ Error: API key/secret not found in .env file")
        sys.exit(1)

    bot = BasicBot(api_key, api_secret, testnet=True)

    print("\n" + "="*40)
    print(" Welcome to Binance Futures Trading Bot ")
    print("="*40 + "\n")

    try:
        symbol = input("➡️  Enter symbol (e.g., BTCUSDT): ").upper()
        side = input("➡️  Enter side (BUY/SELL): ").upper()
        order_type = input("➡️  Enter order type (MARKET/LIMIT): ").upper()
        quantity = float(input("➡️  Enter quantity: "))

        if order_type == "MARKET":
            bot.place_market_order(symbol, side, quantity)
        elif order_type == "LIMIT":
            price = float(input("➡️  Enter limit price: "))
            bot.place_limit_order(symbol, side, quantity, price)
        else:
            print("❌ Invalid order type. Choose MARKET or LIMIT.")

    except ValueError:
        print("❌ Invalid input. Quantity/Price must be numbers.")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == "__main__":
    main()
