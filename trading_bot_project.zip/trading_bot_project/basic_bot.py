import logging
from binance.client import Client
from binance.exceptions import BinanceAPIException

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("trading_bot.log"),
        logging.StreamHandler()
    ]
)

class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.client = self._connect_to_client()

    def _connect_to_client(self):
        try:
            logging.info("Attempting to connect to Binance Futures Testnet...")
            client = Client(self.api_key, self.api_secret)
            if self.testnet:
                client.API_URL = "https://testnet.binancefuture.com"
            logging.info("✅ Connected to Binance Futures Testnet.")
            return client
        except Exception as e:
            logging.error(f"❌ Failed to connect: {e}")
            raise

    def _place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            params = {
                "symbol": symbol,
                "side": side,
                "type": order_type,
                "quantity": quantity
            }
            if price:
                params["price"] = price
                params["timeInForce"] = "GTC"

            logging.info(f"Placing order: {params}")
            order = self.client.futures_create_order(**params)

            logging.info(f"✅ Order placed: {order}")
            print(f"✅ Order ID {order['orderId']} placed for {order['symbol']}")
            return order

        except BinanceAPIException as e:
            logging.error(f"❌ Binance API Error: {e}")
            print(f"❌ Binance API Error: {e.message}")
            return None
        except Exception as e:
            logging.error(f"❌ Unexpected Error: {e}")
            print(f"❌ Unexpected Error: {e}")
            return None

    def place_market_order(self, symbol, side, quantity):
        return self._place_order(symbol, side, "MARKET", quantity)

    def place_limit_order(self, symbol, side, quantity, price):
        return self._place_order(symbol, side, "LIMIT", quantity, price)
